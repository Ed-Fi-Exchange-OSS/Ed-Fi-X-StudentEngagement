var config = {
    api: {"Url":"https://localhost/StudentEngagement/api/LearningActivityEvents"},
    encryptionExportedKey: "4Pmra8SUSrgdU3z_rc-Pf1pQzCK9mdb-jaVc-9cSmCE",
    identification: {
        StudentUniqueId: "123",
        StudentElectronicMail: "doug@ddd.com",
        DeviceId: "A3423-5F898-...."
    }
};