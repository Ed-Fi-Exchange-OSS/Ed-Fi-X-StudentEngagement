Page-Timer Privacy Policy
=========================

All data is kept locally in ram; no data is sent over the network or saved to disk.

Each tab's history is kept only as long as that tab is open.

All data held by this extension is immediately visible in the UI -- click on the
icon to see the history pop-up.  (You may have to scroll.)

The only thing ever put in persistent storage is the history size setting (one
number) configurable on the extension's Options page.
