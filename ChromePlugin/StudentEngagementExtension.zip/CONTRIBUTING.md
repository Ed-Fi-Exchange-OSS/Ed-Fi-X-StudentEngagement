Patches welcome!


Unfortunately, there is one hoop to jump through first,
though: You must complete a Contributor License Agreement:

https://developers.google.com/open-source/cla/individual or
https://developers.google.com/open-source/cla/corporate as appropriate.

(Note: This is _not_ a copyright _assignment_.)

If you have already done this for any other Google project,
you're already done; you don't need to do it again.
